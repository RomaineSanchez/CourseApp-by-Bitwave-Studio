package com.ucc.courseapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class CoursesActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_courses)

        val courseList = listOf(
            Course("IT101", "Introduction to Programming", 3, "None", "Basic programming concepts"),
            Course("IT201", "Data Structures", 3, "IT101", "Fundamental data structures")
        )

        val recyclerView: RecyclerView? = findViewById(R.id.rvCourses)
        recyclerView?.layoutManager = LinearLayoutManager(this)
        recyclerView?.adapter = CourseAdapter(courseList)
    }
}

data class Course(
    val code: String,
    val name: String,
    val credits: Int,
    val prerequisites: String,
    val description: String
)