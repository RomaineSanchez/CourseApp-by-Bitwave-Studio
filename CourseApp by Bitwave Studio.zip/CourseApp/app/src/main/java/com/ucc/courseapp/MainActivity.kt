package com.ucc.courseapp

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.cardview.widget.CardView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<CardView>(R.id.cardDirectory).setOnClickListener {
            startActivity(Intent(this, DirectoryActivity::class.java))
        }

        findViewById<CardView>(R.id.cardCourses).setOnClickListener {
            startActivity(Intent(this, CoursesActivity::class.java))
        }

        findViewById<CardView>(R.id.cardAdmissions).setOnClickListener {
            startActivity(Intent(this, AdmissionsActivity::class.java))
        }

        findViewById<CardView>(R.id.cardSocial).setOnClickListener {
            startActivity(Intent(this, SocialMediaActivity::class.java))
        }

        findViewById<FloatingActionButton>(R.id.fabEmail).setOnClickListener {
            val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:hod@it.ucc.edu.jm")
                putExtra(Intent.EXTRA_SUBJECT, "Query from IT Department App")
            }
            if (emailIntent.resolveActivity(packageManager) != null) {
                startActivity(emailIntent)
            }
        }
    }
}