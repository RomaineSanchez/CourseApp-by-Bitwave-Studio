package com.ucc.courseapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class StaffAdapter(
    private val staffList: List<StaffMember>,
    private val onItemClick: (StaffMember) -> Unit
) : RecyclerView.Adapter<StaffAdapter.StaffViewHolder>() {

    class StaffViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val photo: ImageView = itemView.findViewById(R.id.ivStaffPhoto)
        val name: TextView = itemView.findViewById(R.id.tvStaffName)
        val title: TextView = itemView.findViewById(R.id.tvStaffTitle)
        val phone: TextView = itemView.findViewById(R.id.tvStaffPhone)
        val email: TextView = itemView.findViewById(R.id.tvStaffEmail)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StaffViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_staff, parent, false)
        return StaffViewHolder(view)
    }

    override fun onBindViewHolder(holder: StaffViewHolder, position: Int) {
        val staff = staffList[position]
        holder.photo.setImageResource(staff.photoResId)
        holder.name.text = staff.name
        holder.title.text = staff.title
        holder.phone.text = staff.phone
        holder.email.text = staff.email
        holder.itemView.setOnClickListener { onItemClick(staff) }
    }

    override fun getItemCount(): Int = staffList.size
}