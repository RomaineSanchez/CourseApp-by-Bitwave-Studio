package com.ucc.courseapp

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class DirectoryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_directory)

        val staffList = listOf(
            StaffMember("Dr. John Smith", "Head of Department", "876-123-4567", "john.smith@ucc.edu.jm", R.drawable.profile1),
            StaffMember("Ms. Jane Doe", "Senior Lecturer", "876-234-5678", "jane.doe@ucc.edu.jm", R.drawable.profile2)
        )

        val recyclerView: RecyclerView? = findViewById(R.id.rvStaff)
        recyclerView?.layoutManager = LinearLayoutManager(this)
        recyclerView?.adapter = StaffAdapter(staffList) { staff ->
            when {
                staff.phone.isNotBlank() -> {
                    val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${staff.phone}"))
                    if (dialIntent.resolveActivity(packageManager) != null) {
                        startActivity(dialIntent)
                    }
                }
                staff.email.isNotBlank() -> {
                    val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
                        data = Uri.parse("mailto:${staff.email}")
                    }
                    if (emailIntent.resolveActivity(packageManager) != null) {
                        startActivity(emailIntent)
                    }
                }
            }
        }
    }
}

data class StaffMember(
    val name: String,
    val title: String,
    val phone: String,
    val email: String,
    val photoResId: Int
)