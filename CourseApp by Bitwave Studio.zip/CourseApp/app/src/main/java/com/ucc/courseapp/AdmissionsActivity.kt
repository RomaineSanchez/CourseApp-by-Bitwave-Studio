package com.ucc.courseapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class AdmissionsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admissions)

        val btnApply: Button? = findViewById(R.id.btnApply)
        btnApply?.setOnClickListener {
            val webpage = Uri.parse("https://ucc.edu.jm/apply")
            val webIntent = Intent(Intent.ACTION_VIEW, webpage)
            if (webIntent.resolveActivity(packageManager) != null) {
                startActivity(webIntent)
            } else {
                // Handle the case where no activity can handle the intent
                Toast.makeText(this, "No browser found to open the link", Toast.LENGTH_SHORT).show()
            }
        }
    }
}